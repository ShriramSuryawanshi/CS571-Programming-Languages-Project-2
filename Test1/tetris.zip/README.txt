README file

1. Group Members - 

	1. Name:	Shriram Ananda Suryawanshi
	Email: 	ssuryaw1@binghamton.edu

	2. Name: 	Vinen Vivian Furtado
	Email: 	vfurtad1@binghamton.edu



2. Program Execution - 
	
	To play the game open tetris.html file in any desktop browser.
	The blocks will appear randomly at random start point.
	You can use on-screen buttons or arrow keys to move the block to left and right.
	Once the entire row is formed, all the rows from above will collapse.
	Once you reach top of the canvas, the game will stop. To play again, just reload/refresh the page.



Thank You!
